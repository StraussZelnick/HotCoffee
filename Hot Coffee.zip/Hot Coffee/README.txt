Hot Coffee Mod

REQUIREMENTS:
- ScriptHookRDR2

INSTALLATION:
- Install Alexander Blade's Script Hook RDR2
- Place "HotCoffee.asi" in the root folder of your Red Dead Redemption 2 game directory. 

LOCATIONS SUPPORTED:
- Valentine Saloon
- Saint Denis Saloon
- Strawberry Hotel/Welcome Center

More locations will added as the mod updates

HOW TO USE:
Enter any of the supported locations and approach the prostitute. Follow the prompts. 

CHANGELOG:
1.0 - Initial Release

KNOWN ISSUES/FIXES:
None Currently

If you encounter any other bugs/issues please create a bug report on the Nexus Mod Download page, I'll try my best to fix it as soon as possible. 


Showcase Video - https://youtu.be/A7lpq37FV7o


CREATED BY:
- Unlosing
- Jedijosh920

Special thanks to the following people for testing:
- TagBackTV
